#ifndef _RESTFUL_API_H
#define _RESTFUL_API_H
#include "JsonK.hxx"
namespace eSipUtil
{
//-----------> Restful Message Class
class RestfulParam : public JsonObject
{
	public:
		RestfulParam();
		virtual ~RestfulParam();
		//-----> My Data
		KString & KEY();
		KString & VAL();
		//-----> Is Exist Child
		bool EXIST(const char * _pszKey);
		//-----> Get Child Param
		RestfulParam & GET(const char * _pszParam);
		//-----> Get Array Child Param, Set List Object Attribute
		KString & ARR();
		//-----> Get Array Child
		KString & operator[](unsigned int _unIndex);
		KString & INDEX(unsigned int _unIndex);
		//-----> Get Child Nums
		unsigned int NUMS();
};
class RestfulMsg : public JsonK
{
	public:
		RestfulMsg();
		virtual ~RestfulMsg();
		bool PARSE(const char * _pszJson);
		//-----> Is Exist Child
		bool EXIST(const char * _pszKey);
		//-----> Get Child Param
		RestfulParam & GET(const char * _pszParam);
		//-----> Get Array Child
		RestfulParam & operator[](unsigned int _unIndex);
		//-----> Get Child Nums
		unsigned int NUMS();
		//-----> Get Build Json
		char * STR();
};
//------------> Restful Api Class
class RestfulApi
{
	public:
		RestfulApi(){}
		~RestfulApi(){}
		bool m_fnInit(const char * _pszConfigPath){return true;}
		bool m_fnSend(RestfulMsg & _rclsMsg){return true;}
		virtual void m_fnNotify(bool _bConnect)=0;
		virtual void m_fnRecv(RestfulMsg & _rclsMsg)=0;
};
}
#endif